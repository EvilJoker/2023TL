from src.domain.entities.struct_instance import StructInstance
from src.domain.entities.struct_member import Member

def test_create_struct():
    
    age_member = Member("0", "age", "int", "18", {"json":"age"})
    name_member = Member("1", "name", "char []", "sqy", {"json":"age"})
    struct_instance = StructInstance(struct_name = "T_Student", instance_name = "one_student", members = [age_member, name_member])

    print(struct_instance)
    assert struct_instance.struct_name == "T_Student"

