from src.domain.services.gen_service import GenService


class TestGenService:
    def test_show(self):
        gen_service = GenService()
        gen_service.show()


    def test_gencode_print(self):
        gen_service = GenService()
        file_path = "resource/c/demo2.cpp"
        gen_service.gencode(file_path, "0")

    def test_gencode_tag(self):
        gen_service = GenService()
        file_path = "resource/c/demo2.cpp"
        gen_service.gencode(file_path, "1")

    def test_gencode_serialized(self):
        gen_service = GenService()
        file_path = "resource/c/demo2.cpp"
        gen_service.gencode(file_path, "2")