from src.main import hello, generate_serialized_function_json, generate_print_function, generate_tag_function
import sys
from utilstest import UtoolsTest


def test_hello():
    str1 = "a"
    str2 = "b"
    assert UtoolsTest.append_str(str1, str2) == hello(str1, str2), "比较错误"


def test_generate_print_function():
    filepath = "resource/c/demo5.cpp"
    result = generate_print_function(filepath, "0")
    assert "printf" in result

def test_generate_tag_function():
    filepath = "resource/c/demo5.cpp"
    result = generate_tag_function(filepath, "1")
    assert "GetTagOf" in result

def test_generate_serialized_function_json():
    filepath = "resource/c/demo5.cpp"
    result = generate_serialized_function_json(filepath, "2")
    assert "printf" in result

