import sys
class UtoolsTest:
    # 测试
    @staticmethod
    def append_str(str1, str2):
        return str1 + str2