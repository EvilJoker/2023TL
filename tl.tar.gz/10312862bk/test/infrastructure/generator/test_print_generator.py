from src.infrastructure.generator.print_generator import PrintGenerator
from src.infrastructure.file.struct_loader import load_without_comment


class TestPrintGenerator:

    # 发送初始化 请求
    def test_print_function(self):

        generator = PrintGenerator()

        filepath = "resource/c/demo2.cpp"
        print_func_define = generator.gen_print_function(filepath)
        print(print_func_define)
        assert "printf" in print_func_define
