from src.infrastructure.generator.serialize_generator import SerializeGenerator
from src.infrastructure.file.struct_loader import load_without_comment


class TestPrintGenerator:


    def test_gen_serialized_function_json(self):

        generator = SerializeGenerator()

        filepath = "resource/c/demo2.cpp"
        print_func_define = generator.gen_serialized_function_json(filepath)
        print(print_func_define)
        assert "printf" in print_func_define

