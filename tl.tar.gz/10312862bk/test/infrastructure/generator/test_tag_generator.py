from src.infrastructure.generator.tag_generator import TagGenerator
from src.infrastructure.file.struct_loader import load_without_comment, load_with_comment


class TestTagGenerator:

    # 发送初始化 请求
    def test_gen_tag_function(self):

        generator = TagGenerator()

        filepath = "resource/c/demo2.cpp"
        tag_func_define = generator.gen_tag_function(filepath)
        print(tag_func_define)
        assert "dwAge-json" in tag_func_define