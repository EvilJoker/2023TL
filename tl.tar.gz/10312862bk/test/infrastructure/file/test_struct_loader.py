from src.infrastructure.file.struct_loader import load_without_comment, load_with_comment
import sys
def test_load_without_comment():
    filepath = "resource/c/demo2.cpp"
    source_code = load_without_comment(filepath)
    print(source_code)
    assert "struct" in source_code

def test_load_with_comment():
    filepath = "resource/c/demo2.cpp"
    load_with_comment(filepath)

# 解决typedef 
def test_load_with_comment_transe():
    filepath = "resource/c/demo5.cpp"
    code = load_with_comment(filepath)
    print(code)