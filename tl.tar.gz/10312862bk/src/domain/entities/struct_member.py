class Member:
    def __init__(self):
        self.index = -1 # -1 表示该属性没有值
        self.name = "unknown"
        self.type = "unknown"
        self.tags = {} # k v都是 str
        self.value = 0
    
    def __init__(self, index, name, type, value, tags={}):
        self.index = index
        self.name = name
        self.type = type
        self.tags = tags
        self.value = value

    def __str__(self):
        return "Member " + self.index + ": "  + " "  + self.name + " " + self.type + " " + str(self.value) + " " + str(self.tags)
