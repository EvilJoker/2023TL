class StructInstance:
    def __init__(self):
        self.struct_name = "unknown"
        self.instance_name = "unknown"
        self.members = []


    def __init__(self, struct_name, instance_name, members):
        self.struct_name = struct_name
        self.instance_name = instance_name
        self.members = members

    def __str__(self):

        members_str = []
        for member in self.members:
            members_str.append(str(member))


        return "instance: {} struct: {} {{{} }}".format(self.instance_name, self.struct_name, ", ".join(members_str))