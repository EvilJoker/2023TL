from src.infrastructure.generator.print_generator import PrintGenerator
from src.infrastructure.generator.tag_generator import TagGenerator
from src.infrastructure.generator.serialize_generator import SerializeGenerator
from src.infrastructure.generator.utils import get_struct_instance_by_path
class GenService:
    
    def __init__(self):
        self.generators = {"print_generator": PrintGenerator(), "tag_generator": TagGenerator(), "serialize_generator": SerializeGenerator()}
        self.generators.keys()
        self.instances = {}

    def regist_instance(self, struct_instance):
        self.instances[struct_instance.instance_name] = struct_instance

    def show(self):
        

        instaces_str = []
        for struct_name, struct_instance  in self.instances.items():
            instaces_str.append(str(struct_instance))

        gens_str = ""

        for index, gen in enumerate(self.generators.keys()):
            gens_str +=  str(index) + " " + gen + "; "

        print("generators: \n" + gens_str)
        print("\ninstances: \n" + "\n".join(instaces_str))
    
    def gencode(self, file_path, chose):
        

        gens = list(self.generators.keys())
        if not chose.isdigit():
            print("please input a number in 0 ~ " + str(len(gens) - 1 ))
            return ""
        chose = int(chose)

        if chose >= len(self.generators.keys()) or chose < 0:
            print("please input a number in 0 ~ " + str(len(gens)- 1) )
            return ""

        struct_instance = get_struct_instance_by_path(file_path)

        # 注册实例
        self.regist_instance(struct_instance)
        

        # 展示信息
        self.show()

        print("\nfilepath: " + file_path)
        print("\nchose: " + gens[chose])
        generator = self.generators.get(gens[chose])

        code = generator.gencode(file_path, self.instances)
        #打印结果
        print("\ncode: \n" + code)

        return code

        
