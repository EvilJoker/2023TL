
# 独立运行时，需要去掉 src
import sys
import os

# 获取当前文件所在的目录路径（src 目录）
src_dir = os.path.dirname(os.path.abspath(__file__))

# 将上级目录（项目根目录）添加到模块搜索路径中
project_dir = os.path.dirname(src_dir)
sys.path.append(project_dir)

from src.domain.services.gen_service import GenService
# demo
def hello(str1, str2):
    return str1 + str2

def generate_print_function(filepath, chose) :
    gen_service = GenService()
    code = gen_service.gencode(filepath, chose)
    return code

def generate_tag_function(filepath, chose) :
    gen_service = GenService()
    code = gen_service.gencode(filepath, chose)
    return code

def generate_serialized_function_json(filepath, chose) :
    gen_service = GenService()
    code = gen_service.gencode(filepath, chose)
    return code
# 函数生成

if __name__ == '__main__':
    print("start !!! ")
    # 获取命令行参数
    print("input like : python src/main.py resource/c/demo2.cpp 0")
    if len(sys.argv) < 3:
        print("input not right :" + str(sys.argv))
        sys.exit()

    filepath = sys.argv[1]
    chose = str(sys.argv[2])
    
    # 判断文件是否存在
    if not os.path.exists(filepath):
        print("file not exist :" + filepath)
        sys.exit()

    gen_service = GenService()
    gen_service.gencode(filepath, chose)

    # generate_print_function("resource/c/demo.cpp", "0")


