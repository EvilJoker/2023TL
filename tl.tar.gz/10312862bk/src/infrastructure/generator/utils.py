import re

from pycparser import c_parser, c_ast

from src.domain.entities.struct_instance import StructInstance
from src.domain.entities.struct_member import Member
from src.infrastructure.file.struct_loader import load_without_comment, load_with_comment



Format_MAP = {
            'int': '%d',
            'float': '%f',
            'double': '%f',
            'char': '%c',
            'char[]': '%s',
        }


class StructVisitor(c_ast.NodeVisitor):
    def __init__(self):
        self.struct_list = []

    def get_struct_list(self):
        return self.struct_list

    def visit_Struct(self, node):
        struct_name = node.name
        # print(f"struct: {struct_name}")
        self.struct_list.append(f"struct: {struct_name}")
        for decl in node.decls:
            if isinstance(decl, c_ast.Decl) and isinstance(decl.type, c_ast.TypeDecl):
                member_name = decl.name
                member_type = decl.type.type.names[0]
                # print(f"    Member: {member_type} {member_name}")
                self.struct_list.append(f"member: {member_type} {member_name}")
            # Decl 表示是一个声明 ， ArrayDecl 是一个 数组， TypeDecl 是一个类型
            if isinstance(decl, c_ast.Decl) and isinstance(decl.type, c_ast.ArrayDecl):
                member_name = decl.name
                member_type = decl.type.type.type.names[0]
                # print(f"    Member: {member_type} {member_name}[]")
                self.struct_list.append(f"member: {member_type} {member_name}[]")



# 遍历源代码得到结构体
def get_struct_list(filepath):

    source_code = load_without_comment(filepath)

    parser = c_parser.CParser()
    ast = parser.parse(source_code)
    struct_visitor = StructVisitor()
    struct_visitor.visit(ast)
    result_list = struct_visitor.get_struct_list()
    # print(result_list)
    return result_list

# 遍历源文件，靠字符串解析得到 tag
def get_field_dict(filepath):
    pattern = r"(.+?)\s*\/\/\s*(.+)$"
    pattern1 = r"\[(.+?)\]"
    # 解析 tag
    tag_dict = {}
    struct_code_comment = load_with_comment(filepath)
    lines = struct_code_comment.split('\n')

    for line in lines:
        ret = re.match(pattern, line)
        if ret :
            code_str = ret.group(1).split()[1]
            key = re.sub(pattern1, "", code_str).replace(";", "")
            tag_dict[key] = ret.group(2)

    # 生成 代码需要的 dict
    field_dict = {}
    for key, value in tag_dict.items():
        arr = value.split()
        for kv in arr:
            if len(kv) <= 1:
                continue
            arr2 = kv.split(":")
            new_key = key + "-"+ arr2[0]
            new_value = arr2[1]
            field_dict[new_key] = new_value

    # return {'dwAge-json':'jname', 'dwAge-yaml':'yname'}
    return field_dict

# 遍历 源代码，得到类型
def get_field_type_dict(filepath, struct_list = None):

    if struct_list is None:
        struct_list = get_struct_list(filepath)

    field_type_dict = {}

    for item in struct_list:
        if 'struct' in item:
            field_type_dict["struct"] = item.replace('struct', '').replace(":", "").strip()
        elif 'member' in item:
            item = item.replace('member:', '').strip()
            key = item.split()[1].strip()
            value = item.split()[0].strip()
            
            if "[" in key:
                key = key[:key.index("[")]
                value = value + "[]"

            field_type_dict[key] = value


    return field_type_dict
    # return {'struct':'T_struct', 'dwAge':'int', 'acName': 'char[]'}

def field_dict_to_code(field_dict):
    code_dict = ""
    for key, value in field_dict.items():
        code_dict += "{{\"{}\", \"{}\"}},\n".format(key, value)

    # return "{"dwAge-json", "jage"},\n {"acName-json", "jname"},\n{"acName-yaml", "yaml"},"
    return code_dict


def get_field_dict_code(filepath):

    field_dict = get_field_dict(filepath)
    code = field_dict_to_code(field_dict)
    return code



def get_names_by_struct_names(struct_name):
    
    function_name = "Print" +  struct_name.lower().replace("t_", "", 1).capitalize()
    point_name = "pt" +  struct_name.lower().replace("t_", "", 1).capitalize()
    return struct_name, function_name, point_name

def get_struct_instance_by_path(filepath):

    field_dict = get_field_dict(filepath)
    #{'dwAge-json':'jname', 'dwAge-yaml':'yname'}
    field_type_dict = get_field_type_dict(filepath)
    #{'struct':'T_struct', 'dwAge':'int', 'acName': 'char[]'}

    struct_name = field_type_dict.get('struct', "unknown")
    struct_name, function_name, point_name = get_names_by_struct_names(struct_name)
    field_type_dict.pop('struct')

    members = []
    for index, (filed_name ,type_name) in enumerate(field_type_dict.items(), start=0):
        tags = {}
        for filed_tagkey, tagvalue in field_dict.items():
            if filed_tagkey.startswith(filed_name):
                tagkey = filed_tagkey.replace(filed_name + "_", "", 1)
                tags[tagkey] = tagvalue
        members.append(Member(str(index), filed_name, type_name, "unknown", tags))



    age_member = Member("0", "age", "int", "18", {"json":"age"})
    name_member = Member("1","name", "char []", "sqy", {"json":"age"})
    struct_instance = StructInstance(struct_name = struct_name, instance_name = point_name, members = members)

    return struct_instance
