
from src.infrastructure.generator.utils import Format_MAP, StructVisitor, get_struct_list, get_field_dict_code
from src.infrastructure.file.struct_loader import load_with_comment, load_without_comment, load_with_comment
import re

class TagGenerator:

    def gen_tag_function(self, filepath):
        code_str = get_field_dict_code(filepath)

        template_code = load_with_comment("resource/c/demo2_template.cpp")
        replaced_code = template_code.replace("####", code_str)
 
        return replaced_code

    def gencode(self, file_path, struct_instance):
        return self.gen_tag_function(file_path)



