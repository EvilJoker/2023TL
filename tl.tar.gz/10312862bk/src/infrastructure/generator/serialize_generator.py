
from src.infrastructure.generator.utils import Format_MAP, StructVisitor, get_struct_list, get_field_dict,\
     get_field_type_dict, get_names_by_struct_names

class SerializeGenerator:


    def gencode(self, file_path, struct_instance):
        return self.gen_serialized_function_json(file_path)

    def gen_serialized_function_json(self, filepath):

        # field_type_dict = {'dwAge':'int', 'acName': 'char[]'}
        field_type_dict = get_field_type_dict(filepath)
        field_dict = get_field_dict(filepath)
        # 解析 名称
        struct_name = field_type_dict.get('struct')
        struct_name, function_name, point_name = get_names_by_struct_names(struct_name)
        function_name = function_name.replace("Print", "SerializedJson")

        # 解析 tag 名称
        body_str = ""

        json_field_list = {}
        for key, value in field_dict.items():
            if key.endswith("json"):
                json_field_list[key[:-5]] = value

        for index, (key, value) in enumerate(json_field_list.items(), start=0):
            buf_name = "buf"+str(index)

            body_str += """char {}[100]; // 用于存储结果的缓冲区
            size_t {}len = sizeof({});
            GetTagOfStudentByField("{}", "json", {},  {}len);
            \n
            """.format(buf_name, buf_name, buf_name,  key, buf_name, buf_name)

        # 解析 printf 内容
        left, right="", ""

        for index, (field_name , format) in enumerate(json_field_list.items()):

            type_str = field_type_dict.get(field_name)
            format_str = Format_MAP.get(type_str)

            left += "%s: {}\\n".format(format_str)
            right += "buf{} ,{}->{}, ".format(index, point_name, field_name)
        value_str = "\"{{{}}}\", {}".format(left, right[:-2])

        # 汇总
        template = """int {}(struct {} *{})
        {{
            if (NULL == {} )
            {{
                return -1;
            }}
            // 解析 tag 名称
            {} 
            return printf({});
        }}
        """.format(function_name, struct_name, point_name, point_name, body_str, value_str)

        return template

