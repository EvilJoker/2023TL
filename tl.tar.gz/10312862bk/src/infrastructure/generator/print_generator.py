
from src.infrastructure.generator.utils import Format_MAP, StructVisitor, get_struct_list, get_field_dict,\
     get_field_type_dict, get_names_by_struct_names

class PrintGenerator:


    def gencode(self, file_path, struct_instance):
        return self.gen_print_function(file_path)

    def gen_print_function(self, filepath):
        field_type_dict = get_field_type_dict(filepath)

        # 解析
        struct_name = field_type_dict.get('struct')
        struct_name, function_name, point_name = get_names_by_struct_names(struct_name)

        # 解析 printf 内容
        left, right="", ""

        for field_name, value in field_type_dict.items() :
            if field_name == "struct":
                continue
            type_str = field_type_dict.get(field_name)
            format_str = Format_MAP.get(type_str)

            left += "{}: {}\\n".format(field_name, format_str)
            right += "{}->{}, ".format(point_name, field_name)
        value_str = "\"{}\", {}".format(left, right[:-2])



        template = """int {}(struct {} *{})
        {{
            if (NULL == {} )
            {{
                return -1;
            }}
            
            return printf({});
        }}
        """.format(function_name, struct_name, point_name, point_name, value_str)


        return template
    


