import re

Format_MAP = {
            'int': '%d',
            'float': '%f',
            'double': '%f',
            'char': '%c',
        }
TYPEDEF_MAP = {
            'int': 'INT,WORD32',
            'float': 'FLOAT',
            'double': 'DOUBLE',
            'char': 'CHAR',
    }

def load_without_comment(filepath):
    with open(filepath, 'r') as f:
        code = f.read()
        # 替换代码中的注释
        pattern = r"\/\/\s*(.*?)\s*\n"
        replaced_code = re.sub(pattern, "\n", code)

        replaced_code = transe_line(replaced_code)

        return replaced_code

def load_with_comment(filepath):
    with open(filepath, 'r') as f:
        code = f.read()

        code = transe_line(code)
        return code

def transe_line(context):
    for basic_type, defines_type in  TYPEDEF_MAP.items():
        # 默认类型的定义前后都有空格，或者 CHAR[ 数组
        for define_type in defines_type.split(','):
            define_type = define_type.strip()
            context = context.replace(" {} ".format(define_type), " {} ".format(basic_type))\
                .replace(" {}[".format(define_type), " {}[".format(basic_type))

    return context
