struct T_Student {
    WORD32 dwAge;     // json:jage
    CHAR acName[16];  // json:jname yaml:yname
} T_Student;