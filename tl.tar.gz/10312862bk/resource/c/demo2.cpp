struct T_Student {
    int dwAge;     // json:jage
    char acName[16];  // json:jname yaml:yname
} T_Student;

