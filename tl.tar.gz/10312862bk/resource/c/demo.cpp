struct T_Student {
    int dwAge;
    char acName[16];
} T_Student;